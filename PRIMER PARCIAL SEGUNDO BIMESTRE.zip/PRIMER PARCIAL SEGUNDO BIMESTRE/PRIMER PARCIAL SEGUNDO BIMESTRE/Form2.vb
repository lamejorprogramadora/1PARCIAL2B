﻿Public Class Form2
    Private x As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label1.Text = DateTime.Now.ToString("hh:mm:ss")
        Label2.Text = DateTime.Now.ToString("hh:mm:ss")

        If (x Mod 2 = 0) Then
            Label1.Visible = True
            Label2.Visible = False

        Else
            Label1.Visible = False
            Label2.Visible = True

        End If
        x = x + 1





    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Enabled = True
    End Sub
End Class