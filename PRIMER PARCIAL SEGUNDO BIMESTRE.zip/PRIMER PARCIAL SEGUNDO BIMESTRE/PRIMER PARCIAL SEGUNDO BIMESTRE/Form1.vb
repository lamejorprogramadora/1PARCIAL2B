﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer
        Dim b As String
        Dim c As String

        a = TextBox1.Text

        Select Case (a)
            Case 1
                b = "LUNES"
                c = "ENERO"
            Case 2
                b = "MARTES"
                c = "FEBRERO"
            Case 3
                b = "MIERCOLES"
                c = "MARZO"
            Case 4
                b = "JUEVES"
                c = "ABRIL"
            Case 5
                b = "VIERNES"
                c = "MAYO"
            Case 6
                b = "SABADO"
                c = "JUNIO"
            Case 7
                b = "DOMINGO"
                c = "JULIO"
            Case 8
                b = "NO EXISTE"
                c = "AGOSTO"
            Case 9
                b = "NO EXISTE"
                c = "SEPTIEMBRE"
            Case 10
                b = "NO EXISTE"
                c = "OCTUBRE"
            Case 11
                b = "NO EXISTE"
                c = "NOVIEMBRE"
            Case 12
                b = "NO EXISTE"
                c = "DICIEMBRE"



        End Select
        TextBox2.Text = b
        TextBox3.Text = c
    End Sub
End Class
